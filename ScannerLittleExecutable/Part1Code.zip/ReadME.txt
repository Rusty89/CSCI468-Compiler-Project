To run the project enter the following command

	$ ./Micro.sh path/to/file path/to/file

takes up to 4 arguments

outputs files at same destination as Micro.sh

src files in src folder holds our grammar and driver files used to procude the CompilerProject.jar